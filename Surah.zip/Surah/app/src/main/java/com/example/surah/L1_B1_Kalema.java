package com.example.surah;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class L1_B1_Kalema extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l1__b1__kalema);
        Button button1,button2,button3,button4,button5,button6,button7;
        button1=(Button) findViewById(R.id.l1_button1);
        button2=(Button) findViewById(R.id.l1_button2);
        button3=(Button) findViewById(R.id.l1_button3);
        button4=(Button) findViewById(R.id.l1_button4);
        button5=(Button) findViewById(R.id.l1_button5);
        button6=(Button) findViewById(R.id.l1_button6);
        button7=(Button) findViewById(R.id.l1_button7);
    }
    public void onClick(View v) {
        final int id = v.getId();
        switch (id) {
            case R.id.l1_button1:
                Intent intent1 = new Intent( L1_B1_Kalema.this,B1_K1_Taiyeba.class);
                startActivity(intent1);

                break;
            case R.id.l1_button2:
                Intent intent2 = new Intent( L1_B1_Kalema.this,B1_K2_Shahadat.class);
                startActivity(intent2);
                break;
            case R.id.l1_button3:
                Intent intent3 = new Intent( L1_B1_Kalema.this,B1_K3_Taohid.class);
                startActivity(intent3);
                break;
            case R.id.l1_button4:
                Intent intent4= new Intent(L1_B1_Kalema.this, B1_K4_Tamjid.class);
                startActivity(intent4);
                break;
            case R.id.l1_button5:
                Intent intent5 = new Intent( L1_B1_Kalema.this,B1_K5_Mujmal.class);
                startActivity(intent5);
                break;
            case R.id.l1_button6:

                Intent intent6 = new Intent( L1_B1_Kalema.this,B1_K6_Mufassal.class);
                startActivity(intent6);
                break;
            case R.id.l1_button7:
                Intent intent7 = new Intent( L1_B1_Kalema.this,B1_K7_Raddekufar.class);
                startActivity(intent7);
                break;

        }
    }

}