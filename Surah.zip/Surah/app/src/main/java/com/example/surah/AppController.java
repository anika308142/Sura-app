package com.example.surah;

import android.app.Application;

public class AppController extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        //Initial Font
        FontsOverride.setDefaultFont(getApplicationContext(), "MONOSPACE", "font/solaimanlipi.ttf");

    }
}
