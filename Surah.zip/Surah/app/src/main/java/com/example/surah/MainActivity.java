package com.example.surah;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    Button button1,button2,button3,button4,button5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1=(Button) findViewById(R.id.button1);
        button2=(Button) findViewById(R.id.button2);
        button3=(Button) findViewById(R.id.button3);
        button4=(Button) findViewById(R.id.button4);
        button5=(Button) findViewById(R.id.button5);
    }
    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }
    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                Toast.makeText(this, "Item 1 clicked", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item2:
                Toast.makeText(this, "Item 2 clicked", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item3:
                Toast.makeText(this, "Item 3 clicked", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item4:
                Toast.makeText(this, "Item 4 clicked", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item5:
                Toast.makeText(this, "Item 5 clicked", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item6:
                //Toast.makeText(this, "Item 6 clicked", Toast.LENGTH_SHORT).show();
                Intent intentp6= new Intent(MainActivity.this,P6_about.class);
                startActivity(intentp6);

                return true;
            default:
                return false;
        }
    }

    public void onClick(View v) {
        final int id = v.getId();
        switch (id) {
            case R.id.button1:
                Intent intent1 = new Intent( MainActivity.this,L1_B1_Kalema.class);
                startActivity(intent1);
                break;
            case R.id.button2:
                Intent intent2 = new Intent( MainActivity.this,L1_B2_Durud.class);
                startActivity(intent2);
                break;
            case R.id.button3:
                Intent intent3 = new Intent( MainActivity.this,L1_B3_Sura.class);
                startActivity(intent3);
                break;
            case R.id.button4:
                Intent intent4= new Intent(MainActivity.this, L1_B4_Dua.class);
                        startActivity(intent4);
                break;
            case R.id.button5:
                Intent intent5 = new Intent( MainActivity.this,L1_B5_otirikto.class);
                startActivity(intent5);
                break;

        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }



}