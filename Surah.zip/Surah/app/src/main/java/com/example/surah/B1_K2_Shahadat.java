package com.example.surah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class B1_K2_Shahadat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b1__k2__shahadat);
    }
}