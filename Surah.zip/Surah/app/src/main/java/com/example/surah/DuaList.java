package com.example.surah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DuaList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dua_list);
    }
}