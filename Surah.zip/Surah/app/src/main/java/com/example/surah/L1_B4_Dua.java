package com.example.surah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class L1_B4_Dua extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l1__b4__dua);
    }
}