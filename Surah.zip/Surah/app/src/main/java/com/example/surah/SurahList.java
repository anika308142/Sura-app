package com.example.surah;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SurahList extends AppCompatActivity {
    Button sura1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l1__b3__sura);
        sura1 = (Button) findViewById(R.id.sura1);
    }
    public void displaySurah(View v) {
        final int id = v.getId();
        switch (id) {
            case R.id.sura1:
                Intent intent1 = new Intent( SurahList.this,Fatiha.class);
                startActivity(intent1);
                break;



        }
    }
}