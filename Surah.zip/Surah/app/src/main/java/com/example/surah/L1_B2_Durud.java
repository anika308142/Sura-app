package com.example.surah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class L1_B2_Durud extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l1__b2__durud);
    }
}