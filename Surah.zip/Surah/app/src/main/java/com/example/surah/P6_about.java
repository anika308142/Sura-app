package com.example.surah;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class P6_about extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p6_about);
    }
}